const express = require("express")
const path = require('path');
const app = express();
const port = 80;

const mongoose = require('mongoose');
const { emit } = require("process");
main().catch(err => console.log(err));

async function main() {
    await mongoose.connect('mongodb://localhost/HostelMess');
}

const paymentSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
    },
    phone: {
        type: Number,
        required: true,
    },
    address: {
        type: String,
        required: true,
    },
    email: {
        type: String,
        required: true,
    },
    transaction: {
        type: Number,
        required: true,
    },
});
var Payment = mongoose.model('Payment', paymentSchema);

const feedbackSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
    },
    phone: {
        type: Number,
        required: true,
    },
    newfeed: {
        type: String,
        required: true,
    },
});
var Feedback = mongoose.model('Feedback', feedbackSchema);

app.use('/static', express.static('static'))
app.use(express.urlencoded())

app.set('view engine', 'pug')
app.set('views', path.join(__dirname, 'views'))

app.get('/', (req, res) => {
    res.status(200).render('home.pug');
})

app.get('/menu', (req, res) => {
    res.status(200).render('menu.pug');
})

app.get('/payment', (req, res) => {
    res.status(200).render('payment.pug');
})

app.get('/about', (req, res) => {
    res.status(200).render('about.pug');
})

app.get('/feedback', (req, res) => {
    res.status(200).render('feedback.pug');
})

app.get('/charges', (req, res) => {
    res.status(200).render('charges.pug');
})

app.post('/payment', (req, res) => {
    var data = new Payment(req.body);
    data.save().then(() => {
        res.render('success.pug')
    }).catch(() => {
        res.status(400).render('failed.pug')
    })
});

app.post('/feedback', (req, res) => {
    var data = new Feedback(req.body);
    data.save().then(() => {
        res.render('feedbackSuccess.pug')
    }).catch(() => {
        res.status(400).render('failed.pug')
    })
});

app.get('/contact', (req, res) => {
    res.status(200).render('contact.pug');

})

app.listen(port, () => {
    console.log("Application started successfully")
})